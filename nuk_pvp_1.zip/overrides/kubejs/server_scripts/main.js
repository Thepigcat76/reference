//@ts-check

ServerEvents.recipes((event) => {
  // @ts-ignore
  event.shapeless(
    // @ts-ignore
    Item.of("jujutsucraft:cursed_technique_changer", 1), // arg 1: output
    [
      "minecraft:book",
      "electrodynamics:raworefluorite",
      "electrodynamics:dustobsidian",
    ]
  );
  // @ts-ignore
  event.shapeless(
    // @ts-ignore
    Item.of("bunker_craft:soulbound_pearl", 1), // arg 1: output
    [
      "minecraft:ender_pearl",
      "minecraft:sculk",
      "electrodynamics:dustobsidian",
    ]
  );

  energizedAlloyerRecipe(
    event,
    0.4000000059604645,
    [
      ingredient("electrodynamics:ingotstainlesssteel"),
      ingredient("electrodynamics:dustobsidian"),
    ],
    Item.of("jeg:gunnite_ingot"),
    Item.of("jeg:gunmetal_grit"),
    0.75,
    50,
    50
  );

  reinforcedAlloyerRecipe(
    event,
    0.4000000059604645,
    [
      ingredient("electrodynamics:ingotstainlesssteel"),
      ingredient("electrodynamics:dustobsidian"),
    ],
    Item.of("jeg:gunnite_ingot", 2),
    Item.of("jeg:gunmetal_grit"),
    0.75,
    50,
    50
  );
  event.remove({ id: "jeg:tier_2_workbench_gunnite_ingot" });
  event.remove({ id: "jeg:tier_3_workbench_gunnite_ingot" });
  event.replaceInput(
    { id: "jeg:tier_1_workbench_recycler" },
    "jeg:circuit_board",
    "electrodynamics:circuitadvanced"
  );
  event.replaceInput(
    { id: "jeg:tier_2_workbench_recycler" },
    "jeg:circuit_board",
    "electrodynamics:circuitadvanced"
  );
  event.replaceInput(
    { id: "jeg:tier_3_workbench_recycler" },
    "jeg:circuit_board",
    "electrodynamics:circuitadvanced"
  );

  // @ts-ignore
  event.smelting("3x minecraft:gravel", "minecraft:stone");
});

function ingredient(itemId, count) {
  return {
    item: itemId,
    count: count
  };
}

function tagIngredient(itemId, count) {
  return {
    tag: itemId,
    count: count,
  };
}

/**
 *
 * @param {Internal.RecipesEventJS} event
 * @param {number} experience
 * @param {*[]} inputs
 * @param {Internal.ItemStack} output
 * @param {Internal.ItemStack} biproduct
 * @param {number} bichance
 * @param {number} ticks
 * @param {number} usagepertick
 */
function energizedAlloyerRecipe(
  event,
  experience,
  inputs,
  output,
  biproduct,
  bichance,
  ticks,
  usagepertick
) {
  // @ts-ignore
  event.custom({
    type: "electrodynamics:energized_alloyer_recipe",
    experience: experience,
    itembi: {
      0: {
        chance: bichance,
        count: biproduct.count,
        item: biproduct.id,
      },
      count: 1,
    },
    iteminputs: {
      0: inputs[0],
      1: inputs[1],
      count: 2,
    },
    output: {
      count: output.count,
      item: output.item.id,
    },
    ticks: ticks,
    usagepertick: usagepertick,
  });
}

/**
 *
 * @param {Internal.RecipesEventJS} event
 * @param {number} experience
 * @param {*[]} inputs
 * @param {Internal.ItemStack} output
 * @param {Internal.ItemStack} biproduct
 * @param {number} bichance
 * @param {number} ticks
 * @param {number} usagepertick
 */
function reinforcedAlloyerRecipe(
  event,
  experience,
  inputs,
  output,
  biproduct,
  bichance,
  ticks,
  usagepertick
) {
  // @ts-ignore
  event.custom({
    type: "electrodynamics:reinforced_alloyer_recipe",
    experience: experience,
    itembi: {
      0: {
        chance: bichance,
        count: biproduct.count,
        item: biproduct.id,
      },
      count: 1,
    },
    iteminputs: {
      0: inputs[0],
      1: inputs[1],
      count: 2,
    },
    output: {
      count: output.count,
      item: output.item.id,
    },
    ticks: ticks,
    usagepertick: usagepertick,
  });
}
