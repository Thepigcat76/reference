JEIEvents.hideItems(event => {
    event.hide(/jujutsucraft/)
})