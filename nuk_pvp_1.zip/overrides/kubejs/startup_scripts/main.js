WorldgenEvents.remove(event => {
    event.removeOres
})